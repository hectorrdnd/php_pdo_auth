<?php
$conexion= new PDO("mysql:host=localhost;dbname=practica","root","");
//echo var_dump($conexion);
